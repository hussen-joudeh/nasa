# FieldShift — ten source sample review package

**This is a sample-stage delivery. No full export or MongoDB import has been performed.**

## What is actually available
Two of ten source deliveries contain real extracted sample values: NASA POWER and NRCS SSURGO (Web Soil Survey lineage). They contribute three collections: `climate_daily`, `climate_seasonal`, and `field_soils`. Each has one representative JSONL record and the exact requested mapping CSV headers.

Eight other source deliveries contain **schema examples with null measurements**, criteria mapping proposals and, where obtained, real catalog evidence. Their JSONL files are physically under `schema_only/`, have `record_status=SCHEMA_ONLY_NO_EXTRACTED_MEASUREMENT` and `import_ready=false`. They are not completed science-data samples and must not be imported as observations. No numeric measurement was fabricated. ECOSTRESS has separate LST and ET schema examples.

All collection names other than the three example names in the brief, and all output-field mappings, are PROPOSED. The referenced attachment and shared field list were not available. Criterion labels express the reviewed project uses, not a verified canonical criterion dictionary. The integration owner must agree mappings using the actual reference before full exports.

## Shared location
Region `scottsbluff_gering_ne`; EPSG:4326 bbox [west,south,east,north] = [-103.76,41.79,-103.55,41.93]. The real samples use [-103.655,41.86], the bbox centre. This is not a known farmer field or the team's shared centroid. `field_id` remains null with a reason. No fictitious field boundaries or IDs were introduced.

No raster clipping or field-area aggregation has been completed. The existing source resolutions have not been changed. POWER is a native-resolution point API query; SSURGO is a mapunit intersection at that point. Catalog intersections do not establish valid clear-sky pixels or full time coverage; some returned granules start in 2022 but overlap the requested 2023 start.

## Real representative records
| Source | Collection | Sample |
|---|---|---|
| NASA POWER | climate_daily | 2023-05-01; Tmax 21.69 C, Tmin 0.56 C, RH 31.71%, wind 2.56 m/s, solar 29.26 MJ/m2/day, rain 0 mm |
| NASA POWER | climate_seasonal | 2023-05-01 through 2023-09-30; 20 hot days with Tmax >=35 C, total rain 406.59 mm |
| SSURGO | field_soils | Mapped unit 1653740, Glenberg fine sandy loam, 0-2% slopes; component/horizon properties retained |

POWER's comparison CSV provides the requested second season: May–September 2024 had 34 hot days and 164.92 mm rain. Each season has 153 valid daily values for each requested parameter. These are regional estimates and UTC product days, not on-farm measurements or Nebraska civil days. The 2023 versus 2024 result is not a long-term climate trend. The complete 2023–2025 daily archive is not part of this sample.

SSURGO's dominant mapped component is Glenberg at 99%, with AWC 0.11 cm/cm at 0–48 cm and 0.10 cm/cm at 48–152 cm. The other component is 1%. These are survey representative values: component percentage does not identify its exact position within a mapunit. AWC is storage capacity, not current moisture. No field root-zone storage, field-average pH, current soil test, or effective rooting depth is asserted. Texture and restriction tables were not queried; corresponding proposed outputs remain null.

## Per-source folders
Each of ten folders contains `<source_slug>__criteria_mapping.csv`. Real extracted records are directly in their folder. Null-only proposals are in `schema_only/`. `source_delivery_status.csv` identifies every source and collection's state. `source_catalog_coverage_checks.json` and individual catalog files preserve source URLs, dates and native metadata. Existing raw POWER and SSURGO responses are retained for reproduction.

LP DAAC is a portal; MOD13Q1.061 is the proposed distinct product for that delivery. VIIRS uses VNP13A1.002, not a second copy of the same VIIRS data via another portal. The chosen vegetation composites are not crop-type history. No source from another member's assignment (CDL, OpenET, GAEZ etc.) was silently added. WSS and SSURGO are a single lineage here. Different estimates of rainfall, soil moisture or ET must not be added as if they were different water inputs.

SMAP, IMERG, MODIS, VIIRS, SRTM and ECOSTRESS have prior intersecting CMR metadata, not extracted raster samples. IMERG V07 daily query returned fewer records than the 1096 target days; version transition and coverage must be checked. ECOSTRESS catalog evidence uses V002 and does not approve a switch to V003. Landsat coverage remains unverified through the proper USGS discovery route; the attempted CMR zero result is not evidence of no coverage. The attempted ORNL MODIS subset service timed out. Ag Data Commons requires a study matched to demo crops and criteria; no study was selected and no agronomic rule or study measurements are invented.

## Information still needed
1. The referenced attachment: exact final filenames, criterion definitions, field names and MongoDB collection mappings.
2. Shared demo field list with field_id values and polygons/centroids, preferably GeoJSON with declared CRS.
3. Farmer crop/planting history and irrigation allocation with unit and period; crop/soil-specific root depth where needed.
4. Evidence of a selected field's canal service in 2019 before any field-level outage impact is asserted. The outage remains regional historical context from the project brief.

## Sample review and next stage
Review the three real records and all proposed mappings first. Confirm the reference, shared fields and sample/time convention. Then perform missing source extraction, QA and native-resolution clipping, and the applicable 2023–2025 export. Do not run an automatic import of this package. The integration owner combines approved source deliveries into final MongoDB collections.

JSON parsing, stable unique string IDs within each file, numeric measurements, finite numbers, ISO dates where present, region IDs, null reasons, and CSV headers are checked in `validation_report.json`. Shared field references and canonical schema validation are **blocked**, not passed. Schema-only examples do not count as extracted-sample completeness.

## شرح سريع للفريق
الحزمة تغطي المصادر العشرة في خريطة المعايير، لكن القيم الفعلية الجاهزة للعينة حالياً من POWER والتربة SSURGO فقط. ملفات بقية المصادر داخل schema_only تعرض الشكل المقترح بقيم null وأسباب النقص، وليست قياسات. نحتاج ملف المرجع وحدود الحقول ومعرّفاتها حتى نثبت الربط ونراجع العينة قبل التصدير الكامل. لا يوجد إدخال إلى MongoDB بعد.
