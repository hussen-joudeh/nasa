# FieldShift source delivery

USDA field and crop history, crop profiles and scenarios, with station, county, market, imagery, landscape, OpenET, GEDI and GAEZ evidence at their documented scopes.

The manifest lists canonical collection candidates and supplemental sources with coverage and open gaps. Original extracted evidence and source metadata are under evidence/original. Original JSONL evidence is stored as JSON arrays so only the corrected source exports use the JSONL extension. PRISM and NASA POWER use different daily windows. See source metadata for each dataset.
