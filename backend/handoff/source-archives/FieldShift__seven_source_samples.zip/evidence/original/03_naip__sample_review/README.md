# naip: sample review

الاستخدام: مرجع بصري وحدود وسياق مكاني؛ ليس سجل محاصيل مصنفاً جاهزاً. الملف يتضمن بيانات أصل الصورة وبصمتها فقط؛ لا يتضمن صورة مقصوصة أو NDVI.
التغطية المؤكدة: صورة USDA بتاريخ 2024-07-13 تغطي نقطة العينة، بدقة اسمية 0.6 متر وفق كود 060 في اسم الأصل وخدمة بأربع حزم. خدمة USGS الأقدم أعادت صورة 2022؛ تم تفضيل أصل 2024. أول طلب USDA أعاد كاليفورنيا فرفضناه؛ طلب NE الصريح أعاد البصمة الصحيحة.
حجم الديمو: صورة واحدة مناسبة زمنياً لكل حقل أو أصول مشتركة للمنطقة؛ قص الرستر لاحقاً دون تغيير دقته. تقدير القيم غير المضغوطة لصورة U8 بأربع حزم = المساحة بالمتر المربع / 0.6² × 4 بايت؛ 1 كم² يقارب 11.1 MB قبل الضغط والهوامش. هذا تقدير وليس حجم تنزيل مقاساً.
Latency: مناسب للسياق والتخطيط، ولا يكفي لمراقبة النبات اليومية؛ تاريخ الالتقاط أهم من سرعة عرض الخريطة. صورة يوليو 2024 لا تثبت حالة الحقل في 2025 أو عبر كل الموسم.
التخزين: أصل الصورة في مخزن ملفات، والروابط والتاريخ والدقة والبصمة في MongoDB. بصمة العينة تقع داخل صندوق المنطقة؛ لا يوجد تصدير بكسلات يحتاج قصاً هنا.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://naip-usdaonline.hub.arcgis.com/
- https://imagery.nationalmap.gov/arcgis/rest/services/USGSNAIPImagery/ImageServer
- https://apps.geo.fpac.usda.gov/geo-imagery/rest/services/naip/conus_naip_cache/ImageServer
