# earthdata_gldas: sample review

الاستخدام: سياق نمذجي لرطوبة التربة وحالة سطح الأرض؛ Earthdata بوابة، والمنتج المختار تحديداً GLDAS Noah 2.1 بدقة 0.25 درجة وفاصل 3 ساعات. ليست قياسات مباشرة داخل الحقل، ولا نخلطها مع NLDAS.
حالة العينة: بيانات الكتالوج والملف بتاريخ 2023-08-22 موثقة، لكن تنزيل NetCDF أعاد HTTP 401. لا توجد قياسات مستخرجة؛ كل المدخلات العددية المطلوبة null مع السبب.
حجم الديمو المقترح بعد إتاحة الدخول: خلية/خلايا المنطقة فقط، 3 متغيرات × 8 خطوات يومياً × 1096 يوماً في 2023–2025 = 26,304 قيمة لكل خلية، نحو 105,216 بايت عند float32 للقيم فقط. لا يمثل حجم ملفات NetCDF أو MongoDB.
Latency: مناسب كتاريخ نمذجي للتخطيط بعد التأكد من آخر تاريخ متاح، وليس اعتماداً على توقع وصول فوري. لا نخلط فاصل المنتج 3 ساعات مع تأخر نشره؛ تاريخ تحديث الكتالوج ليس بالضرورة أول تاريخ إصدار. سرعة الوصول غير قابلة للتقييم من طلب 401.
التخزين: مجموعة فرعية زمنياً ومكانياً مع أسماء المتغيرات ووحداتها وأعماقها. تحويل kg/m² إلى رطوبة حجمية يحتاج سمك الطبقة وكثافة الماء؛ لا نسجل القيمة نفسها تحت حقل volumetric soil moisture.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://www.earthdata.nasa.gov/
- https://ldas.gsfc.nasa.gov/gldas
- https://ldas.gsfc.nasa.gov/gldas/parameters
- https://docserver.gesdisc.eosdis.nasa.gov/public/project/hydrology/README_GLDAS2.pdf
- https://cmr.earthdata.nasa.gov/search/collections.json?short_name=GLDAS_NOAH025_3H&version=2.1
