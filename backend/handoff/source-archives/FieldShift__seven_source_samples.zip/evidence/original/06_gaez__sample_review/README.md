# gaez: sample review

الاستخدام: سياق نمذجي طويل الأمد لملاءمة المحصول ومقارنة الري بالمطر، وليس إثبات المحصول المزروع أو مردود الحقل.
تم استخراج قيمتي بكسل فعليتين للذرة MZE في سيناريو HIST/AGERA5 للفترة 2001–2020: HILM وHRLM. الدقة الفعلية لهذه الملفات 5 دقائق قوسية (0.083333 درجة)، وليست 800 متر أو 30 متراً. لا نصغر الخلايا لتبدو أكثر دقة.
تنبيه دلالي: عُثر على اسم مؤشر الملاءمة والسيناريوهات، لكن لم يُثبت جدول الوحدات/المقياس الخاص بـRES05-SIX؛ نحفظ القيم الخام فقط ولا نسميها نسبة مئوية أو فئة عالية/ضعيفة. الاستعمال في التوصيات معلّق حتى التحقق من هذا الجدول.
حجم الديمو: طبقتان لمحصول واحد كبداية، مقصوصتان للمنطقة؛ ليست كل المحاصيل أو السيناريوهات العالمية. قصّنا الخلايا الأصلية المتقاطعة دون إعادة أخذ عينات؛ قد تمتد حافتها خارج الصندوق بمقدار جزء خلية. الأبعاد والحجم والـhash داخل evidence. المصدر الأصلي العالمي استُخدم للاستخراج ولم يضمَّن كاملاً.
Latency: مناسب للمقارنة الاستراتيجية طويلة المدى؛ المنتج المناخي 2001–2020 لا يصف الموسم الحالي ولا يعوّض طقس 2023–2025 اليومي. زمن تنزيل العينة ليس حداثة البيانات.
التخزين: حفظ crop/period/scenario/water-management/native grid لكل قيمة؛ عدم دمج rainfed وirrigated في حقل مبهم. القصاصات TIFF محفوظة منفصلة عن JSONL.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://gaez.fao.org/
- https://github.com/un-fao/gaezv5/wiki/21.-GAEZ-v5-Platform-User-Guide
- https://storage.googleapis.com/fao-gismgr-gaez-v5-data/DATA/GAEZ-V5/MAPSET/RES05-SIX/GAEZ-V5.RES05-SIX.HP0120.AGERA5.HIST.MZE.HILM.tif
- https://storage.googleapis.com/fao-gismgr-gaez-v5-data/DATA/GAEZ-V5/MAPSET/RES05-SIX/GAEZ-V5.RES05-SIX.HP0120.AGERA5.HIST.MZE.HRLM.tif
