# cocorahs: sample review

الاستخدام: تقرير مطر من محطة فعلية داخل المنطقة للمقارنة المكانية والتحقق من التباين؛ ليس قياساً لكل حقل. المصدر الرسمي أعاد 4 تقارير داخل الصندوق للتاريخ المختار، واختيرت NE-SB-13 كسجل ممثل: 0.0 مم، وليس قيمة مفقودة.
حجم الديمو المقترح: جميع المحطات داخل الصندوق في الفترة اللازمة، وتوثيق جيران خارج المنطقة فقط إذا استُخدموا مع مسافة واضحة. العينة سجل JSONL واحد وأربعة تقارير خام مقصوصة مكانياً ليوم واحد. عند اكتمال 2023–2025، الحد النظري لمحطة واحدة 1096 تقريراً يومياً؛ التوفر الفعلي قد ينقص. عدد محطات يوم العينة لا يثبت استمرارها طوال السنوات.
Latency: مناسب للتحقق اليومي والتاريخي عندما يصل التقرير، لكنه يعتمد على إدخال المتطوع؛ بعض تقارير اليوم المختار أُدخلت بعد أيام. لا ضمان موحد لتأخر النشر، ولا نستخدمه وحده لتشغيل ري لحظي. حقول الوقت الخام لا تتضمن منطقة زمنية صريحة، لذلك لم نحولها إلى UTC تخميناً.
التخزين: station_id مع وقت الرصد والفترة والوحدة ووقت الإدخال والـQC إذا توفر؛ لا نخزن NA/Trace على أنها صفر. هذه العينة صفر عددي كما ورد في المصدر.
المقارنة: PRISM قد يستخدم تقارير CoCoRaHS ضمن مدخلاته؛ المقارنة مفيدة لكنها ليست تحققاً مستقلاً بالضرورة. لا نجمع موسماً ناقصاً كأنه كامل، ولا نخلط يوم المحطة بيوم PRISM المنتهي 12:00 UTC.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://www.cocorahs.org/Maps/
- https://data.cocorahs.org/cocorahs/export/exportreports.aspx
- https://www.cocorahs.org/Content.aspx?page=Hilbergstips
- https://media.cocorahs.org/docs/CoCoRaHS_QA_QC_April_2019.pdf
