# usda_ssurgo: sample review

الاستخدام: دعم خصائص التربة واحتفاظها بالماء ودرجة الحموضة والصرف. تم جلب وحدة التربة فعلياً عند نقطة العينة، ثم المكوّن الأكبر والأفق السطحي فقط؛ ليست عينة مختبر حديثة.
حجم الديمو المقترح: وحدات التربة المتقاطعة مع الحقول فقط، مع مكوناتها وآفاقها اللازمة لعمق الجذور؛ إزالة تكرار mukey/cokey/chkey. لا حاجة لتنزيل الولايات المتحدة. عدد السجلات النهائي يتحدد بعد وصول الحدود؛ العينة هنا سجل واحد.
Latency: مناسب للتخطيط الموسمي لأنه مسح تربة بنسخة مؤرخة، وليس حساس رطوبة لحظياً. النسخة الجارية ليست وصفاً مؤكداً للتربة في 2023–2025. زمن طلبات العينة موثق في evidence؛ لا نعد بزمن نشر ثابت.
التخزين الصحيح: الاحتفاظ بالآفاق ووحداتها؛ لاحقاً حساب متوسطات موزونة بسمك الأفق ونسب المكونات ومساحة تقاطع الحقل، مع إظهار الجزء غير المغطى. لا نحول نسب المكونات إلى نسب مساحة حقل من دون تقاطع.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://www.nrcs.usda.gov/resources/data-and-reports/soil-survey-geographic-database-ssurgo
- https://sdmdataaccess.nrcs.usda.gov/QueryHelp.aspx
- https://sdmdataaccess.nrcs.usda.gov/documents/FundamentalQuery.pdf
