# annual_nlcd: sample review

الاستخدام: التحقق من سياق الغطاء الأرضي الزراعي والتغير السنوي العام؛ فئة Cultivated Crops لا تحدد ذرة أو قمحاً ولا تثبت أن الأرض متروكة.
التغطية: وصف الخدمة يعرض سنوات حتى 2025 وشبكة أصلية 30 متر EPSG:5070. فشلت طلبات WCS 2.0.1 ثم نجح WCS 1.0.0 بإخراج GeoTIFF حقيقي 10×10 بكسل بدقة 30 م حول نقطة العينة. قيمة النقطة 23 (Developed, Medium Intensity)، وليست أرضاً زراعية. هذا يؤكد أن منتصف الصندوق ليس حقلاً مختاراً، ولا يجوز نسبته لأي field_id. ملف الرستر ومواصفات شبكة الإخراج مضمنة؛ لا نعتبر شبكة إخراج الخدمة دليلاً على تطابق محاذاتها تماماً مع الشبكة المصدرية.
حجم الديمو المخطط: طبقة غطاء واحدة للمنطقة لكل سنة 2023–2025، وطبقة الثقة فقط إذا احتجناها. بايت واحد لكل بكسل للفئة إذا كان المنتج U8، دون تكرار الرستر لكل حقل. الحجم النهائي يقاس بعد الاستخراج؛ المطلوب ليس كل الولايات المتحدة.
Latency: تحديث سنوي مناسب للتخطيط ومقارنة الغطاء، وليس لمراقبة تغير أسبوعي. نجح تنزيل قصاصة 2023 عبر الخدمة البديلة؛ هذا لا يعني أن باقي السنوات صُدّرت أو تحقق اكتمالها.
التخزين والمعالجة: قص عند الدقة الأصلية، وحساب نسب الفئات داخل الحقل لاحقاً. تجنب bilinear للطبقات الفئوية، واحتفظ NoData منفصلاً. لا تستخدم وحدة الإشعاع الافتراضية في وصف WCS لفئات الغطاء؛ output unit = class code.


هذه عيّنة للمراجعة قبل التصدير الكامل، وليست بيانات نهائية لحقول الفريق.
المرجع المرفق تقرير مصادر؛ لا يتضمن عقد MongoDB أو قائمة field_id وحدود الحقول.
لذلك أسماء المجموعات والحقول المقترحة تحتاج مطابقة مع الفريق قبل الدمج.
نقطة العيّنة هي منتصف صندوق المنطقة حسابياً، وليست مركز حقل أو متوسط المنطقة.
لا تُنسب العيّنة لحقل فعلي: field_id = null وسبب النقص محفوظ.
ميزانية الري وحجم المياه المتاح يقدمهما المزارع. لا نستنتجهما من المطر أو صلاحية المحصول.
حادثة قناة Gering–Fort Laramie عام 2019 سياق إقليمي فقط؛ ارتباط الحقل بها غير مثبت.

Integration: review schema, obtain shared fields, intersect at native resolution,
retain source/version/time/unit/method, stage and validate, then upsert by stable _id.
Do not import these samples into production field collections. Validate foreign keys
against the actual shared list after it arrives. Keep rasters in object storage;
MongoDB stores asset URLs, hashes and derived numeric summaries, not expanded pixels.
No fabricated measurements, no missing-to-zero conversion, no automatic imputation.
Measurement classifications refer to values, not to catalog metadata.
Latency timings in request logs are single measured requests, not an SLA or publication delay.


## Sources
- https://www.usgs.gov/centers/eros/science/annual-nlcd
- https://www.mrlc.gov/data-services-page
- https://www.usgs.gov/centers/eros/science/annual-nlcd-data-access
