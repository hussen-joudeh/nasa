# FieldShift — PRISM sample only / عينة PRISM فقط

## Status and scope
Real PRISM values, not invented climate data. PROPOSED schema only; not approved for MongoDB import.
The attached DOCX is a source evaluation document, not the database reference. It contains no `field_id`, `climate_daily`, `climate_seasonal`, MongoDB mapping, shared field boundaries or centroids. The two collection names below come from the user's examples and remain proposals pending the missing contract.

Source order in the attachment: PRISM → USDA NRCS SSURGO/STATSGO2 → NAIP → Annual NLCD → Earthdata NLDAS/GLDAS → GAEZ → CoCoRaHS. Only PRISM was processed here; no other teammate source was collected.

Region: `scottsbluff_gering_ne`. Bounding box [west,south,east,north]: [-103.76, 41.79, -103.55, 41.93].
Sample location: bbox midpoint [-103.655, 41.86] (lon, lat), selected by arithmetic, NOT a team field centroid. `field_id: null` with reason. No fictitious field polygon or field area. No result here is a region-wide average or a field recommendation.

## Files for review before full processing
- `prism__climate_daily.jsonl`: exactly one representative day, 2023-08-22, chosen as highest exported Tmax in the 2023 season.
- `prism__climate_seasonal.jsonl`: exactly one representative May–September 2023 season.
- `prism__criteria_mapping.csv`: requested eight headers; field/criterion IDs and collection mappings are explicitly proposed.
- `validation_report.json`: what passed and what remains blocked.
- `evidence/`: two original 153-day CSV series, raw service JSON, request parameters and timings, and computed season comparison. These support the samples; they are not a complete annual climate export.
- `processing/`: reproducible fetch and packaging scripts. Fetch script uses the observed Data Explorer web-client RPC, not a promised stable public production API. Production access should be agreed against official PRISM web-service documentation.

## Actual seasonal comparison at the sample point
| PRISM date-label season | Days complete | Precipitation mm | Tmax >= 35 C days | Mean daily Tmin C | Mean daily Tmax C |
|---|---:|---:|---:|---:|---:|
| May–September 2023 | 153/153 | 467.58 | 12 | 12.1647 | 27.4163 |
| May–September 2024 | 153/153 | 182.13 | 30 | 12.1889 | 29.5614 |

35 C is the team's comparison threshold, not a validated damage threshold for all crops. Means of minima/maxima are not published `tmean`. PRISM values are station-informed model estimates; aggregates are calculated. Do not label them direct field observations.

## Time, space and quality
CSV headers confirm dataset `AN91d`, resolution `800m`, SI units and `Grid Cell Interpolation: Off`. No spatial resampling. The native grid spacing is 30 arcseconds, not an identical 800 x 800 metre square everywhere. Exact raster row/column and per-grid release identifiers are not exposed by this point export, so these are null with reasons.
A PRISM label day is the 24 hours ending 12:00 UTC. May–September here uses labels May 1 through September 30 inclusively. It does not silently align with midnight local time or POWER LST. A midnight-aligned daily maximum/minimum cannot be recovered exactly from these daily extremes alone.
Raw CSV values agree exactly with the arrays in the returned JSON. Dates are consecutive and unique; 153 expected records per season; all values finite; precipitation nonnegative; Tmin <= Tmax. Missing values would remain null, not zero. Incomplete-season totals/counts must remain null under this proposed strict policy, with observed coverage preserved.
All periods are older than the normal six-month revision window; exact grid release date/count was not independently queried. Snapshot hashes and generation/access times preserve this extraction.

## Size and latency
Actual source CSV response bodies: 4,559 and 4,544 bytes; together 9,103 bytes. JSON response bodies: 2,856 and 2,815 bytes. These are returned body sizes, not total wire traffic including headers or a claim about global rasters.
Observed timings (two requests, not an SLA): 2023 query 6.573 s + CSV 12.755 s; 2024 query 5.783 s + CSV 6.121 s. User-interface HTML retrieval is not counted as data latency.
The proposed complete daily range 2023–2025 has 1,096 date labels. For one sample pixel and three variables this is 3,288 values or 13,152 bytes at 4 bytes/value, excluding all metadata, dates, JSON overhead and database indexes. Full spatial export depends on final field list or an explicit regional raster scope; this estimate is not a download measurement. Cache by native pixel and dataset version, not by duplicating each nearby field.
PRISM normally first runs a daily grid about 24 hours after its day ends and revises it for about six months. Historical demo data suit prefetch/caching. Do not block every comparison on a live request.

## Inputs outside PRISM
PRISM cannot provide crop history, soil properties, actual irrigation budget, field area without geometry, or proof a selected field was served by the affected canal in 2019. Nulls and missing reasons are included in the seasonal sample. The farmer must provide water volume, units and season. No documented canal event or field linkage is claimed by this delivery.

## Required next inputs / المطلوب قبل التكامل
أرسلوا مرجع أسماء الملفات والحقول وMongoDB mappings الفعلي، وقائمة field_id وحدود الحقول ومراكزها عند توفرها. المخطط داخل هذه العينة مقترح فقط. بعد تأكيد السجلين والـmapping نكمل المصدر الأول للفترة 2023–2025؛ لا ننتقل تلقائيًا لباقي المصادر ولا ننشئ التصدير الكامل قبل تأكيد الفريق.

## Sources and attribution
PRISM Group, Oregon State University; accessed 2026-11-14.
- Overview: https://prism.oregonstate.edu/overview/
- Data Explorer and day definition: https://prism.oregonstate.edu/explorer/
- Public-client implementation used to locate the sample request: https://prism.oregonstate.edu/explorer/dataexplorer/js/explorer.js?r=1189b
- Official gridded downloads: https://prism.oregonstate.edu/documents/PRISM_downloads_web_service.pdf
- Update schedule: https://prism.oregonstate.edu/calendar/
- Use conditions: https://prism.oregonstate.edu/terms/
Original export URLs (may expire) are retained in `evidence/csv_source_*.json`; local copies and SHA256 snapshots are provided.
